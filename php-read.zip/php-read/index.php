<?php
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
    <title>PHP MySQL Data Read</title>
</head>
<body>

<!-- ===== 
In this example, we've embedded the PHP code that reads data from the MySQL database directly into the HTML file. The PHP code generates a table that displays the data retrieved from the database. The while loop outputs a new row in the table for each row in the database. 
If there are no rows returned, the code outputs a single row with a "0 results" message.
 ===== -->
    <!-- initiating the table header -->
 <table>
        <tr>
            <th>Name</th>
            <th>Age</th>
        </tr>
        
        <!-- PHP code to connect and fetching data from database then creating the output table rows-->
        <?php
        // // Connect to the database
        // $host = "localhost";
        // $username = "root";
        // $password = ""; 
        // $database = "php_read";

        // Create a new mysqli object
        $conn = new mysqli($host, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Define the query
        $sql = "SELECT * FROM mytable";

        // Execute the query
        $result = $conn->query($sql);

        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["name"]. "</td><td>" . $row["age"]. "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2'>0 results</td></tr>";
        }

        // Close the connection
        $conn->close();
        ?>
    </table>
</body>
</html>
