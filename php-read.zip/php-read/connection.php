<?php
        // Connect to the database
        $host = "localhost";
        $username = "root";
        $password = ""; 
        $database = "php_read";

            // Create a new mysqli object
            $conn = new mysqli($host, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }